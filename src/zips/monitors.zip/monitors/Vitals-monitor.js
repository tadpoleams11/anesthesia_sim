// Vitals-monitor.js
// Monitors: Heart Rate, SpO2, Arterial Pressure, etCO2 :)

class VitalsWaveformRenderer {
    constructor(canvas, type) {
        this.canvas = canvas;
        this.type = type;
        this.ctx = canvas.getContext('2d');
        this.printHead = 0;
        this.data = [];
        this.customWaveform = null;
        this.waveformOffset = 0;
        this.baselineY = 0;

        this.resizeCanvas();
        window.addEventListener('resize', () => this.resizeCanvas());
    }

    resizeCanvas() {   
        // Configure canvas
        const rect = canvas.getBoundingClientRect();
        this.canvas.width = rect.width * window.devicePixelRatio;
        this.canvas.height = rect.height * window.devicePixelRatio;
        this.ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
        this.ctx.setTransform(1, 0, 0, 1, 0, 0); // Reset transform

        // Re-init data array to match new width
        const width = Math.floor(this.canvas.width / window.devicePixelRatio);
        this.data = new Array(width).fill(0);

        // Set default baseline
        const height = canvas.height / window.devicePixelRatio;
        this.baselineY = height * 0.67;
    }

        setCustomVitalsWaveform(waveformData) {
        this.customWave = waveformData;
        
        // Update baseline if provided in metadata
        if (waveformData.metadata && typeof waveformData.metadata.baselineRatio === 'number') {
            const height = this.canvas.height / window.devicePixelRatio;
            this.baselineY = height * waveformData.metadata.baselineRatio;
        }
    }

    getColor() {
        const colors = {
            hr: '#24cf21ff',
            spo2: '#02dafcff',
            art: '#c40000ff'
        };
        return colors[this.type] || '#FFF';
    }

    generateDataPoint(time) {
        // Simulate different waveforms
        switch(this.type) {
            case 'hr': // Heart rate (ECG-like)
                const bpm = 75;
                const cycle = (time * bpm / 60) % 1;
                // Simple QRS complex
                if (cycle < 0.05) return 40 * Math.exp(-100 * Math.pow(cycle - 0.025, 2));
                if (cycle < 0.1) return -10 * Math.exp(-200 * Math.pow(cycle - 0.075, 2));
                return 0;
            case 'spo2': // SpO2 plethysmograph
                const spo2Rate = 1.2; // Hz
                return 20 * Math.sin(2 * Math.PI * spo2Rate * time) + 10 * Math.sin(4 * Math.PI * spo2Rate * time);
            case 'art': // Arterial pressure
                const sys = 120, dia = 80;
                const artCycle = (time * 75 / 60) % 1;
                if (artCycle < 0.2) return sys - (sys - dia) * (artCycle / 0.2);
                return dia + (sys - dia) * Math.exp(-10 * (artCycle - 0.2));
            default:
                return 0;
        }
    }

    update(time) {
        const width = this.canvas.width / window.devicePixelRatio;
        const height = this.canvas.height / window.devicePixelRatio;

        //clear area around print head
        this.ctx.fillStyle = '#000000';
        this.ctx.fillRect(this.printHead - 2, 0, 24, height);

        //new data point
        const newPoint = this.generateDataPoint(time);
        this.data[this.printHead] = newPoint;

        // Draw waveform
        this.ctx.strokeStyle = this.getColor();
        this.ctx.lineWidth = 2;
        this.ctx.beginPath();

        let lastX = null;
        for(let i = 0; i < width; i++) {
            const x = (this.printHead - i + width) % width;
            const y = this.baselineY - this.data[x];
            if(i === 0) {
                this.ctx.moveTo(x, y);
                lastX = x;
            } else {
                // Break the path if we're wrapping around
                if (x > lastX) {
                    this.ctx.stroke();
                    this.ctx.beginPath();
                    this.ctx.moveTo(x, y);
                } else {
                    this.ctx.lineTo(x, y);
                }
                lastX = x;
            }
        }
        this.ctx.stroke();

        //draw black rectangle at print head
        this.ctx.fillStyle = '#000000';
        this.ctx.fillRect(this.printHead, 0, 20, height);

        // Move print head forward
        this.printHead = (this.printHead + 1) % width;
    }
}

class VitalsMonitor extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
    }

    connectedCallback() {
        this.shadowRoot.innerHTML = `
            <style>
                :host { 
                    display: block; 
                    width: 100%; 
                    height: 100%; 
                    min-width: 0;
                    min-height: 0;
                }

                .monitor { 
                    display: flex;
                    flex-direction: column;
                    background: #000; 
                    color: #fff; 
                    height: 100%; 
                    padding: 10px; 
                    min-width: 0;
                    min-height: 0;
                    position: relative;
                }

                .status-bar {
                    background: #666;
                    color: white;
                    padding: 8px;
                    transition: all 0.3s;
                }

                .status-bar.warning {
                    background: yellow;
                    color: black;
                }

                .vitals-area { 
                    flex: 1 1 0;
                    min-height: 40px;
                    height: 100%;
                    display: flex;
                    flex-direction: column;
                    gap: 10px;
                }

                .vital-row { 
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    gap: 12px;
                    min-height: 40px;
                }

                .vital-row.selected{
                    border-color: #fafd24ff;
                    box-shadow: 0 0 10px rgba(255, 255, 0, 0.51);  
                }

                .vital-canvas { 
                    flex: 1 1 0;
                    min-width: 40px;
                    width: 100%; 
                    aspect-ratio: 4/1;
                    max-width: 100%;
                    max-height: 80px;
                    min-height: 40px;
                    background: #000; 
                    border: 1px solid #333; 
                    display: block;
                }

                .vital-value { 
                    font-size: 2em; 
                    min-width: 80px; 
                    text-align: right;
                    
                }

                .vital-label {
                    min-width: 60px;
                    font-weight: bold;
                    
                }
                /* Make the text the same colour as the wave */
                .vital-label.hr, .vital-value.hr { color: #2fff00ff; }
                .vital-label.spo2, .vital-value.spo2 { color: #02bdfcff; }
                .vital-label.art, .vital-value.art { color: #db0202ff; }
                .vital-label.ST, .vital-value.ST { color: #2fff00ff; }

                

                /* gas display styling*/
                .gas-monitoring {
                    position: absolute;  
                    bottom: 24px;
                    left: 96px;
                    background: rgba(0,0,0,0.3);
                    border-radius: 6px;
                    border: 1px solid #db0202ff; 
                    padding: 8px 16px 6px 16px;        
                }
                .sevf-gas {
                    position: absolute;
                    bottom: 18px;
                    right: 24px;
                    color: #fafd24ff;
                    font-size: 20px;
                    text-align: right;
                    background: rgba(0,0,0,0.5);
                    border-radius: 6px;
                    padding: 8px 16px 6px 16px;
                    z-index: 10;
                    min-width: 70px;
                }
                .gas-label {
                    display: flex;
                    flex-direction: column;
                    flex: 1 1 0;
                    text-align: left;
                    gap: 5px;
                    font-size: 20 px
                
                }
                .gas-label.o2 {color: #ffffffff;}
                .gas-label.n2o {color: #0011ffff;}

             

            </style>


            <div class="monitor">
                <div class="display">
                     <div class="status-bar">Status message goes here</div>
                    <div class="vitals-area">
                        <div class="vital-row">
                            <span class="vital-label hr">HR</span>
                            <canvas class="vital-canvas" data-label="hrCanvas"></canvas>
                            <span class="vital-value hr" data-label="hrValue" style="cursor:pointer">75</span> bpm
                        </div>

                        <div class="vital-row">
                            <span class="vital-label ST">ST ||</span>
                            <canvas class="vital-canvas" data.label="STCanvas" id="STCanvas"></canvas>
                            <span class="vital-value ST" data-label="STValue" style="cursor:pointer">0.3</span> mm
                        </div>
                        
                        <div class="vital-row">
                            <span class="vital-label art">ART</span>
                            <canvas class="vital-canvas" data-label="artCanvas" id="artCanvas"></canvas>
                            <span class="vital-value art" data-label="artValue" style="cursor:pointer">120/80</span> mmHg
                        </div>

                        <div class="vital-row">
                            <span class="vital-label spo2">SpO₂</span>
                            <canvas class="vital-canvas" data-label="spo2Canvas" id="spo2Canvas"></canvas>
                            <span class="vital-value spo2" data-label="spo2Value" style="cursor:pointer">98</span>%
                        </div>

                        <div class="vital-row">
                            <span class="vital-label etCO2">etCO2</span>
                            <canvas class="vital-canvas" data-label="etC02Canvas" id="etCO2Canvas"></canvas>
                            <span class="vital-value etCO2" data-label="etCO2Value" style="cursor:pointer">32</span> mmHg
                        </div>

                        <div class="vital-row">
                            <span class="vital-label NIBP">NIBP</span>
                            <span class="vital-value NIBP" data-label="NIBP" style="cursor:pointer">118 / 80 (90) </span> mmHg
                        </div>
                    </div>

                    <div class ="gas-monitoring">
                        <div class="gas-label" data-label="o2">
                            <span>O2 0 0</span>
                        </div>
                        <div class="gas-label" data-label="n2o">
                            <span>N20 0 0</span>
                        </div>
                    </div>

                    <div class="sevf-gas" data-label="SEVF%">SEV%<br>0<br>0</div>


                </div>
                
                
            </div>
        `;
        // Listen for SEVF% changes from anesthesia monitor
       

        this.initializeMonitor();
        
    }

    initializeMonitor() {
        this.vitalCanvas = {
            hr: new VitalsWaveformRenderer(this.shadowRoot.getElementById('hrCanvas'), 'hr'),
            spo2: new VitalsWaveformRenderer(this.shadowRoot.getElementById('spo2Canvas'), 'spo2'),
            art: new VitalsWaveformRenderer(this.shadowRoot.getElementById('artCanvas'), 'art')
        };
        this.hrValue = this.shadowRoot.getElementById('hrValue');
        this.spo2Value = this.shadowRoot.getElementById('spo2Value');
        this.artValue = this.shadowRoot.getElementById('artValue');
        this.startTime = performance.now();
        this.animate();
    }

    animate() {
        const time = (performance.now() - this.startTime) / 1000;
        // Update waveforms
        Object.values(this.vitalCanvas).forEach(canvas => canvas.update(time));
        // Update value displays
        if (this.hrValue) this.hrValue.textContent = Math.round(75 + 2 * Math.sin(time));
        if (this.spo2Value) this.spo2Value.textContent = Math.round(98 + 0.5 * Math.sin(time * 0.5));
        if (this.artValue) this.artValue.textContent = `${120 + Math.round(5 * Math.sin(time))}/${80 + Math.round(3 * Math.cos(time))}`;
        requestAnimationFrame(() => this.animate());
    }
}

customElements.define('vitals-monitor', VitalsMonitor);
