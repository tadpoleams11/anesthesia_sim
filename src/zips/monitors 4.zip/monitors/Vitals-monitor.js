// Vitals-monitor.js
// Monitors: Heart Rate, SpO2, Arterial Pressure, etCO2 :)

class VitalsWaveformRenderer {
    constructor(canvas, type) {
        this.canvas = canvas;
        this.type = type;
        this.ctx = canvas.getContext('2d');
        this.printHead = 0;
        this.data = [];
        this.customWaveform = null;
        this.waveformOffset = 0;
        this.baselineY = 0;

        this.resizeCanvas();
        window.addEventListener('resize', () => this.resizeCanvas());
    }

    resizeCanvas() {   
        // Configure canvas
        const rect = this.canvas.getBoundingClientRect();
        this.canvas.width = rect.width * window.devicePixelRatio;
        this.canvas.height = rect.height * window.devicePixelRatio;
        this.ctx.setTransform(1, 0, 0, 1, 0, 0); // Reset transform
        this.ctx.scale(window.devicePixelRatio, window.devicePixelRatio);

        // Re-init data array to match new width
        const width = Math.floor(this.canvas.width / window.devicePixelRatio);
        this.data = new Array(width).fill(0);

        // Set default baseline
        const height = this.canvas.height / window.devicePixelRatio;
        this.baselineY = height * 0.67;
    }

        setCustomVitalsWaveform(waveformData) {
        this.customWave = waveformData;
        
        // Update baseline if provided in metadata
        if (waveformData.metadata && typeof waveformData.metadata.baselineRatio === 'number') {
            const height = this.canvas.height / window.devicePixelRatio;
            this.baselineY = height * waveformData.metadata.baselineRatio;
        }
    }

    getColor() {
        const colors = {
            hr: '#24cf21ff',
            spo2: '#02dafcff',
            art: '#c40000ff',
            etco2: '#ffffff'
        };
        return colors[this.type] || '#FFF';
    }

    generateDataPoint(time) {
        // Simulate different waveforms

        
        
        const bpm = 75;
        const cycle = (time * bpm / 60) % 1;

        switch(this.type) {
            
            case 'hr': // Heart rate (ECG-like)
                // Simple QRS complex
                if (cycle < 0.05) return 40 * Math.exp(-100 * Math.pow(cycle - 0.025, 2));
                if (cycle < 0.1) return -10 * Math.exp(-200 * Math.pow(cycle - 0.075, 2));
                return 0;
            case 'spo2': // SpO2 plethysmograph
                //add case for low perfusion
                const spo2Rate = 1.2; // Hz
                return 20 * Math.sin(2 * Math.PI * spo2Rate * time) + 10 * Math.sin(4 * Math.PI * spo2Rate * time);
            case 'art': // Arterial pressure SAME AS SPO2 RN WILL NEED TO CHANGE
                const sys = 120, dia = 80;
                const artRate = 1.4;
                return 20 * Math.sin(2 * Math.PI * artRate * time) + 10 * Math.sin(4 * Math.PI * artRate * time);
                //if (cycle < 0.2) return sys - (sys - dia) * (cycle / 0.2);
                //return dia + (sys - dia) * Math.exp(-10 * (cycle - 0.2));
            default:
                return 0;
        }
    }

    update(time) {
        const width = this.canvas.width / window.devicePixelRatio;
        const height = this.canvas.height / window.devicePixelRatio;

        //clear area around print head
        this.ctx.fillStyle = '#000000';
        this.ctx.fillRect(this.printHead - 2, 0, 24, height);

        //new data point
        const newPoint = this.generateDataPoint(time);
        this.data[this.printHead] = newPoint;

        // Draw waveform
        this.ctx.strokeStyle = this.getColor();
        this.ctx.lineWidth = 2;
        this.ctx.beginPath();

        let lastX = null;
        for(let i = 0; i < width; i++) {
            const x = (this.printHead - i + width) % width;
            const y = this.baselineY - this.data[x];
            
            if(i === 0) {
                this.ctx.moveTo(x, y);
                lastX = x;
            } else {
                // Break the path if we're wrapping around
                if (x > lastX) {
                    this.ctx.stroke();
                    this.ctx.beginPath();
                    this.ctx.moveTo(x, y);
                } else {
                    this.ctx.lineTo(x, y);
                }
                lastX = x;
            }
        }
        this.ctx.stroke();

        //draw black rectangle at print head
        this.ctx.fillStyle = '#000000';
        this.ctx.fillRect(this.printHead, 0, 20, height);

        // Move print head forward
        this.printHead = (this.printHead + 1) % width;
    }
}

class VitalsMonitor extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
    }

    connectedCallback() {
        this.shadowRoot.innerHTML = `
            <style>
                :host { 
                    display: block; 
                    width: 100%; 
                    height: 100%; 
                    min-width: 0;
                    min-height: 0;
                }

                .monitor { 
                    display: flex;
                    flex-direction: column;
                    background: #000; 
                    color: #fff; 
                    height: 100%; 
                    padding: 10px; 
                    min-width: 0;
                    min-height: 0;
                    position: relative;
                }

                .status-bar {
                    background: #666;
                    color: white;
                    padding: 8px;
                    transition: all 0.3s;
                }

                .status-bar.warning {
                    background: yellow;
                    color: black;
                }

                .vitals-area { 
                    flex: 1 1 0;
                    min-height: 40px;
                    height: 100%;
                    display: flex;
                    flex-direction: column;
                    gap: 10px;
                    border: 1px solid #ffd025ff;
                    
                }

                .vital-row { 
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    gap: 12px;
                    min-height: 40px;
                    border: 1px solid #25fff4ff;           
                    }

                .vital-canvas { 
                    flex: 1 1 0;
                    min-width: 40px;
                    width: 100%; 
                    aspect-ratio: 4/1;
                    max-width: 100%;
                    max-height: 80px;
                    height: 100%;
                    min-height: 0;
                    background: #000; 
                    border: 1px solid #ff2599ff;
                }

                .vital-value { 
                    font-size: 4em; 
                    min-width: 50px;
                    text-align: right;
                    padding: 10px 10px 10px 10px;
                    border: 1px solid #000;
                    background: #000; 
                        
                }

                .vital-value.selected{
                    border: 1px solid;
                    border-color: #fafd24ff;
                    box-shadow: 0 0 5px rgba(255, 255, 0, 0.8);  
                }

                .vital-label {
                    min-width: 60px;
                    font-weight: bold;
                    border: 1px solid #8725ffff;
                    
                }
                /* Make the text the same colour as the wave */
                .vital-label.hr, .vital-value.hr { color: #2fff00ff; }
                .vital-label.spo2, .vital-value.spo2 { color: #02bdfcff; }
                .vital-label.art, .vital-value.art { color: #db0202ff; }
                .vital-label.ST, .vital-value.ST { color: #2fff00ff; }
                .vital-label.etco2, .vital-value.etco2 { color: #ffffff; }
                .vital-label.NIBP, .vital-value.NIBP { color: #ffffff; }

                

                /* gas display styling*/
                .gas-monitoring {
                    position: absolute;  
                    bottom: 24px;
                    left: 96px;
                    background: rgba(0,0,0,0.3);
                    border-radius: 6px;
                    border: 1px solid #db0202ff; 
                    padding: 8px 16px 6px 16px;        
                }
                .sevf-gas {
                    position: absolute;
                    bottom: 18px;
                    right: 24px;
                    color: #fafd24ff;
                    font-size: 20px;
                    text-align: right;
                    background: rgba(0,0,0,0.5);
                    border-radius: 6px;
                    padding: 8px 16px 6px 16px;
                    z-index: 10;
                    min-width: 70px;
                }
                .gas-label {
                    display: flex;
                    flex-direction: column;
                    flex: 1 1 0;
                    text-align: left;
                    gap: 5px;
                    font-size: 20 px
                
                }
                .gas-label.o2 {color: #ffffffff;}
                .gas-label.n2o {color: #0011ffff;}

                /* popup window modal style */

                .modal {
                    display: none; /* Hidden by default */
                    position: fixed; /* Stay in place */
                    z-index: 25; /* Sit on top */
                    width: 50%; 
                    height: 50%; 
                    
                }

                .modal-content{
                    background-color: #c6c4c49e;
                    margin: 15% auto; /* 15% from the top and centered */
                    padding: 20px;
                    border: 1px solid #888;
                    width: 80%; /* Could be more or less, depending on screen size */
                    max-width: 500px;
                    position: relative;
                }

                .close-button {
                    color: #aaa;
                    float: right;
                    font-size: 28px;
                    font-weight: bold;
                    cursor: pointer;
                }

                .close-button:hover,
                .close-button:focus {
                    color: black;
                    text-decoration: none;
                    cursor: pointer;
                }

                .slider-container {

                    width: 100%;
                
                }

                .slider{
                    -webkit-appearance: none;  /* Override default CSS styles */
                    appearance: none;
                    width: 100%; /* Full-width */
                    height: 25px; /* Specified height */
                    background: #d3d3d3; /* Grey background */
                    outline: none; /* Remove outline */
                    opacity: 0.7; /* Set transparency (for mouse-over effects on hover) */
                    -webkit-transition: .2s; /* 0.2 seconds transition on hover */
                    transition: opacity .2s;
                
                } 
                
                .slider:hover {
                    opacity: 1;
                }

                /* The slider handle (use -webkit- (Chrome, Opera, Safari, Edge) and -moz- (Firefox) to override default look) */
                .slider::-webkit-slider-thumb {
                    -webkit-appearance: none; /* Override default look */
                    appearance: none;
                    width: 25px; /* Set a specific slider handle width */
                    height: 25px; /* Slider handle height */
                    background: #9c04aaff; 
                    cursor: pointer; /* Cursor on hover */
                }

                .slider::-moz-range-thumb {
                    width: 25px; /* Set a specific slider handle width */
                    height: 25px; /* Slider handle height */
                    background: #9c04aaff; 
                   cursor: pointer; /* Cursor on hover */
                }
             

            </style>


            <div class="monitor">
                <div class="display">
                     <div class="status-bar">Status message goes here</div>

                    <div class="vitals-area">
                        <div class="vital-row">
                            <span class="vital-label hr">HR</span>
                            <canvas class="vital-canvas" data-label="hrCanvas" id="hrCanvas"></canvas>
                            <button class="vital-value hr" data-label="hrValue" id="hr" style="cursor:pointer">75</button> bpm
                        </div>

                        <div class="vital-row">
                            <span class="vital-label ST">ST ||</span>
                            <canvas class="vital-canvas" data-label="STCanvas" id="STCanvas"></canvas>
                            <button class="vital-value ST" data-label="STValue" id=ST style="cursor:pointer">0.3</button> mm
                        </div>
                        
                        <div class="vital-row">
                            <span class="vital-label art">ART</span>
                            <canvas class="vital-canvas" data-label="artCanvas" id="artCanvas"></canvas>
                            <button class="vital-value art" id="art" data-label="artValue" style="cursor:pointer">120/80</button> mmHg
                        </div>

                        <div class="vital-row">
                            <span class="vital-label spo2">SpO₂</span>
                            <canvas class="vital-canvas" data-label="spo2Canvas" id="spo2Canvas"></canvas>
                            <button class="vital-value spo2" data-label="spo2Value" id="spo2" style="cursor:pointer">98</button>%
                        </div>

                        <div class="vital-row">
                            <span class="vital-label etCO2">etCO2</span>
                            <canvas class="vital-canvas" data-label="etco2Canvas" id="etCO2Canvas"></canvas>
                            <button class="vital-value etco2" id="etco2" data-label="etCO2Value" style="cursor:pointer">32</button> mmHg
                        </div>

                        <div class="vital-row">
                            <span class="vital-label NIBP">NIBP</span>
                            <button class="vital-value NIBP" data-label="NIBP" style="cursor:pointer">118 / 80 (90) </button> mmHg
                        </div>
                    </div>

                    <div class ="gas-monitoring">
                        <div class="gas-label" data-label="o2">
                            <span>O2 0 0</span>
                        </div>
                        <div class="gas-label" data-label="n2o">
                            <span>N20 0 0</span>
                        </div>
                    </div>

                    <div class="sevf-gas" data-label="SEVF%">SEV%<br>0<br>0</div>

                    <div class="modal" id="valModal">
                        <div class="modal-content">
                            <span class="close-button">&times;</span>
                            <span id="modalName"></span>
                            <p>self destruct initiated</p>
                            <div class="slidecontainer">
                                <input type="range" min="1" max="100" value="50" class="slider" id="myRange">
                                <span id="slideVal">
                            </div>

                        </div>

                    </div>
                </div>
                
                
            </div>
        `;
       
        this.initializeMonitor();
        
    }

    //voila
    initializeMonitor() {
        this.vitalCanvas = {
            hr: new VitalsWaveformRenderer(this.shadowRoot.getElementById('hrCanvas'), 'hr'),
            spo2: new VitalsWaveformRenderer(this.shadowRoot.getElementById('spo2Canvas'), 'spo2'),
            art: new VitalsWaveformRenderer(this.shadowRoot.getElementById('artCanvas'), 'art')
        };

        //this.hrValue = this.shadowRoot.getElementById('hrValue');
        //this.spo2Value = this.shadowRoot.getElementById('spo2Value');
        //this.artValue = this.shadowRoot.getElementById('artValue');
        this.sevChange();
        this.initControl();
        //start animating the monitor (initializes time and calls animate)
        this.startTime = performance.now();
        this.animate();
    }
    
    //dud rn but should update SEV value accoridng to other monitor
    sevChange(){
        window.addEventListener('sevChange', (e) => {
            alert('i heard an event happen');
            val = e.detal.value;
            const gasSevf = this.shadowRoot.querySelector('.sevf-gas[data-label="SEVF5"] span');
            if(gasSevf){
                gasSevf.innerHTML = 'SEV%<br>${val}<br>0';
            }
        });
    }

    //establishes click zones
    initControl(){
        //identify the areas to update
        const controlledValues = this.shadowRoot.querySelectorAll('.vital-value');
        //individually recognize clicky spots, give them each a click handler
        //add or remove from 'selected' list

        controlledValues.forEach(conVal => {
            conVal.addEventListener('click', () => {
                
                if (this.selectedConVal) {
                    
                    
                    this.selectedConVal.classList.remove('selected');
                }
                    
                conVal.classList.add('selected');
                
                    this.selectedConVal = conVal;
                    this.initModal();   
                
            });
        });

        

    }
    //little window to adjust values
    initModal(){
        // Get the modal from shadow DOM
        const modal = this.shadowRoot.getElementById("valModal");
        // Get the <span> element that closes the modal
        const span = this.shadowRoot.querySelector(".close-button");
        // Show the modal
        modal.style.display = "block";


        const slider = this.shadowRoot.getElementById("myRange");
        const output = this.shadowRoot.getElementById("slideVal");
        output.innerHTML = slider.value; // Display the default slider value

        if (span) {
            span.onclick = () => {
                modal.style.display = "none";
            };
        }

        // Update the current slider value (each time you drag the slider handle)
        slider.oninput = function() {
            output.innerHTML = this.value;
        }

        // When the user clicks on <span> (x), close the modal
       


    }

    animate() {
        //understanding of passage of time
        const time = (performance.now() - this.startTime) / 1000;

        // Update waveforms
        Object.values(this.vitalCanvas).forEach(canvas => canvas.update(time));

        // Update value displays IDK IF I'M KEEPING THESE THEY'RE SENTIMENETAL BAD LINES
        //if (this.hrValue) this.hrValue.textContent = Math.round(75 + 2 * Math.sin(time));
        //if (this.spo2Value) this.spo2Value.textContent = Math.round(98 + 0.5 * Math.sin(time * 0.5));
        //if (this.artValue) this.artValue.textContent = `${120 + Math.round(5 * Math.sin(time))}/${80 + Math.round(3 * Math.cos(time))}`;

        //recursively calls self to update time and waveforms
        requestAnimationFrame(() => this.animate());
    }
}

customElements.define('vitals-monitor', VitalsMonitor);
